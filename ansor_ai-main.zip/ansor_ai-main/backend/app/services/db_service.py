import logging
from typing import List, Optional, Any, Dict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from sqlalchemy.orm import selectinload
from ..models import User, Chat, Message, Media, MessageType, ChatType
from ..api import schemas

logger = logging.getLogger("ansor_ai.db_service")

class DBService:
    async def get_user_by_username(self, db: AsyncSession, username: str) -> Optional[User]:
        """Foydalanuvchini username orqali topish."""
        result = await db.execute(select(User).where(User.username == username))
        return result.scalars().first()

    async def get_user_by_email(self, db: AsyncSession, email: str) -> Optional[User]:
        """Foydalanuvchini email orqali topish."""
        result = await db.execute(select(User).where(User.email == email))
        return result.scalars().first()

    async def get_user_by_google_id(self, db: AsyncSession, google_id: str) -> Optional[User]:
        """Foydalanuvchini Google ID orqali topish."""
        result = await db.execute(select(User).where(User.google_id == google_id))
        return result.scalars().first()

    async def create_user(self, db: AsyncSession, user_in: schemas.UserCreate, hashed_password: str) -> User:
        """Yangi foydalanuvchi yaratish."""
        db_user = User(
            username=user_in.username,
            full_name=user_in.full_name,
            email=user_in.email,
            hashed_password=hashed_password,
            avatar_url=user_in.avatar_url
        )
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        return db_user

    async def create_google_user(self, db: AsyncSession, email: str, full_name: str, google_id: str, avatar_url: Optional[str] = None) -> User:
        """Google orqali kirgan yangi foydalanuvchi yaratish."""
        # Username sifatida emailning bosh qismini olamiz
        username = email.split("@")[0] + "_" + google_id[:4]
        
        db_user = User(
            username=username,
            full_name=full_name,
            email=email,
            hashed_password=None,
            google_id=google_id,
            avatar_url=avatar_url
        )
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        return db_user

    async def update_user(self, db: AsyncSession, user_id: int, user_update: schemas.UserUpdate) -> User:
        """Foydalanuvchi ma'lumotlarini yangilash."""
        result = await db.execute(select(User).where(User.id == user_id))
        db_user = result.scalars().first()
        
        if db_user:
            update_data = user_update.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(db_user, key, value)
            
            await db.commit()
            await db.refresh(db_user)
            logger.info(f"Foydalanuvchi yangilandi: ID={user_id}")
        
        return db_user

    async def get_chats(self, db: AsyncSession, skip: int = 0, limit: int = 100) -> List[Chat]:
        result = await db.execute(
            select(Chat).order_by(desc(Chat.created_at)).offset(skip).limit(limit)
        )
        return result.scalars().all()

    async def create_chat(self, db: AsyncSession, name: Optional[str] = None, chat_type: ChatType = ChatType.PRIVATE) -> Chat:
        db_chat = Chat(name=name, type=chat_type)
        db.add(db_chat)
        await db.commit()
        await db.refresh(db_chat)
        logger.info(f"Chat yaratildi: ID={db_chat.id}, Type={chat_type}")
        return db_chat

    async def get_messages(self, db: AsyncSession, chat_id: int, skip: int = 0, limit: int = 50) -> List[Message]:
        query = (
            select(Message)
            .where(Message.chat_id == chat_id)
            .options(selectinload(Message.media))
            .order_by(desc(Message.created_at))
            .offset(skip)
            .limit(limit)
        )
        result = await db.execute(query)
        messages = result.scalars().all()
        return messages[::-1]

    async def create_message(
        self, 
        db: AsyncSession, 
        sender_id: int, 
        chat_id: int, 
        content: str, 
        msg_type: MessageType = MessageType.TEXT,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Message:
        db_msg = Message(
            sender_id=sender_id,
            chat_id=chat_id,
            content=content,
            type=msg_type,
            metadata_json=metadata
        )
        db.add(db_msg)
        await db.commit()
        await db.refresh(db_msg)
        return db_msg

    async def add_media(
        self, 
        db: AsyncSession, 
        message_id: int, 
        file_path: str, 
        file_type: str,
        file_name: Optional[str] = None,
        file_size: Optional[int] = None
    ) -> Media:
        db_media = Media(
            message_id=message_id,
            file_path=file_path,
            file_type=file_type,
            file_name=file_name,
            file_size=file_size
        )
        db.add(db_media)
        await db.commit()
        await db.refresh(db_media)
        return db_media

db_service = DBService()
