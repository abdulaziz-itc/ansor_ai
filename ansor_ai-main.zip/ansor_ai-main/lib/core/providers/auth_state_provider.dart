import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/repository/auth_repository.dart';
import '../../data/models/user_model.dart';

enum AuthStatus { initial, authenticated, unauthenticated, loading }

class AuthState {
  final AuthStatus status;
  final UserModel? user;
  final String? errorMessage;

  AuthState({required this.status, this.user, this.errorMessage});

  factory AuthState.initial() => AuthState(status: AuthStatus.initial);
  factory AuthState.loading() => AuthState(status: AuthStatus.loading);
  factory AuthState.authenticated(UserModel user) => AuthState(status: AuthStatus.authenticated, user: user);
  factory AuthState.unauthenticated({String? error}) => AuthState(status: AuthStatus.unauthenticated, errorMessage: error);
}

final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final repository = ref.watch(authRepositoryProvider);
  return AuthNotifier(repository);
});

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _repository;

  AuthNotifier(this._repository) : super(AuthState.initial()) {
    checkAuth();
  }

  Future<void> checkAuth() async {
    final token = await _repository.getToken();
    if (token != null) {
      try {
        final user = await _repository.getCurrentUser();
        state = AuthState.authenticated(user);
      } catch (e) {
        // If fetching user fails, token might be invalid
        await _repository.clearToken();
        state = AuthState.unauthenticated();
      }
    } else {
      state = AuthState.unauthenticated();
    }
  }

  Future<void> login(String username, String password) async {
    state = AuthState.loading();
    try {
      final success = await _repository.login(username, password);
      if (success) {
        final user = await _repository.getCurrentUser();
        state = AuthState.authenticated(user);
      } else {
        state = AuthState.unauthenticated(error: "Failed to retrieve token");
      }
    } catch (e) {
      state = AuthState.unauthenticated(error: e.toString());
    }
  }

  Future<void> register(String username, String email, String password, String? fullName) async {
    state = AuthState.loading();
    try {
      final success = await _repository.register(username, email, password, fullName: fullName);
      if (success) {
        final user = await _repository.getCurrentUser();
        state = AuthState.authenticated(user);
      } else {
        state = AuthState.unauthenticated(error: "Failed to create account");
      }
    } catch (e) {
      state = AuthState.unauthenticated(error: e.toString());
    }
  }

  Future<void> signInWithGoogle() async {
    state = AuthState.loading();
    try {
      final success = await _repository.signInWithGoogle();
      if (success) {
        final user = await _repository.getCurrentUser();
        state = AuthState.authenticated(user);
      } else {
        state = AuthState.unauthenticated(error: "Sign-in was canceled.");
      }
    } catch (e) {
      state = AuthState.unauthenticated(error: e.toString());
    }
  }

  Future<void> logout() async {
    await _repository.logout();
    state = AuthState.unauthenticated();
  }
}
